package com.cts.atomic;

public class Decrement implements Runnable{
	private Counter counter;
	public Decrement(Counter c)
	{
		counter=c;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(counter.getCount());
		counter.decrement();
	}

}
