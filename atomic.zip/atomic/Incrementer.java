package com.cts.atomic;

import java.util.concurrent.atomic.AtomicInteger;

public class Incrementer extends Thread{
	
	
	
	public Incrementer(String name)
	{
		this.setName(name);
		
	}
	@Override
	public void run()
	{
		
		
		System.out.println(CommonClass.inc() +"updated by ---->"+ this.getName());
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
