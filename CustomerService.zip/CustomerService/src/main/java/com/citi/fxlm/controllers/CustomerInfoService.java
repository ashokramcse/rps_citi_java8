package com.citi.fxlm.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.citi.fxlm.models.Customer;

@RestController
public class CustomerInfoService {

	
	@RequestMapping("/customers")
	public List<Customer> getCustomers()
	{
		
		return Customer.getData();
	}
	
	@RequestMapping(value="/search/{id}",method=RequestMethod.GET, produces="application/json")
	public Optional<Customer> searchById(@PathVariable int id)
	{
		return Customer.getData().stream().filter(c->c.getCustomerId()==id).findFirst();
		
		
	}
	
	
}
