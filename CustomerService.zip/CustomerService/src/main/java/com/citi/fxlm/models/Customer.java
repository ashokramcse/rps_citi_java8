package com.citi.fxlm.models;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;



public class Customer {

	private int customerId;
	private String name;
	private LocalDate dob;
	
	
	public Customer(int customerId, String name, LocalDate dob) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.dob = dob;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	
	public static List<Customer> getData()
	{
		List<Customer> customerList=new ArrayList<Customer>();
		customerList.add(new Customer(2456,"Param",LocalDate.of(1970, 12, 2)));
		customerList.add(new Customer(45324,"Eswari",LocalDate.of(1974, 1, 2)));
		customerList.add(new Customer(4543,"Bala",LocalDate.of(1965, 4, 27)));
		customerList.add(new Customer(5435,"Vignesh",LocalDate.of(1995, 12, 7)));
		return customerList;
				
	}
	
	
}
